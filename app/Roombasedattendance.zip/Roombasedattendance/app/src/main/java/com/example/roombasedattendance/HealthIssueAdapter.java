package com.example.roombasedattendance;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

// Adapter for displaying health issues in RecyclerView
public class HealthIssueAdapter extends FirebaseRecyclerAdapter<HealthIssue, HealthIssueAdapter.HealthIssueViewHolder> {

    // Constructor
    public HealthIssueAdapter(FirebaseRecyclerOptions<HealthIssue> options) {
        super(options);
    }

    @Override
    protected void onBindViewHolder(HealthIssueViewHolder holder, int position, HealthIssue model) {
        // Bind the health issue data to the view holder
        holder.tvHealthIssue.setText(model.getHealthIssue());
        holder.tvRoomNumber.setText("Room: " + model.getRoomNumber());
        holder.tvRegNumber.setText("Reg No: " + model.getRegNumber());
        holder.tvStudentName.setText("Student: " + model.getStudentName());
    }

    @Override
    public HealthIssueViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        // Inflate the item layout for each health issue
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_health_issue, parent, false);
        return new HealthIssueViewHolder(view);
    }

    // ViewHolder class to hold the views for each health issue item
    public static class HealthIssueViewHolder extends RecyclerView.ViewHolder {
        TextView tvHealthIssue, tvRoomNumber, tvRegNumber, tvStudentName;

        public HealthIssueViewHolder(View itemView) {
            super(itemView);
            tvHealthIssue = itemView.findViewById(R.id.tv_health_issue);
            tvRoomNumber = itemView.findViewById(R.id.tv_room_number);
            tvRegNumber = itemView.findViewById(R.id.tv_reg_number);
            tvStudentName = itemView.findViewById(R.id.tv_student_name);
        }
    }
}
