package com.example.roombasedattendance;


public class MessFeedback {
    private String feedback;
    private String timestamp;

    // Default constructor required for calls to DataSnapshot.getValue(MessFeedback.class)
    public MessFeedback() {
    }

    // Constructor for the feedback object
    public MessFeedback(String feedback, String timestamp) {
        this.feedback = feedback;
        this.timestamp = timestamp;
    }

    public String getFeedback() {
        return feedback;
    }

    public void setFeedback(String feedback) {
        this.feedback = feedback;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }
}
