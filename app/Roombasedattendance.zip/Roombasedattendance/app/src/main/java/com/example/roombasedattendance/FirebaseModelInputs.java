package com.example.roombasedattendance;

public class FirebaseModelInputs {
}
