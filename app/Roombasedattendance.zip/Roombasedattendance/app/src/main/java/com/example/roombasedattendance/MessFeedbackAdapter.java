package com.example.roombasedattendance;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.example.roombasedattendance.R;
import java.util.List;

public class MessFeedbackAdapter extends RecyclerView.Adapter<MessFeedbackAdapter.FeedbackViewHolder> {

    private List<MessFeedback> feedbackList;

    public MessFeedbackAdapter(List<MessFeedback> feedbackList) {
        this.feedbackList = feedbackList;
    }

    @Override
    public FeedbackViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_mess_fdbk, parent, false);
        return new FeedbackViewHolder(view);
    }

    @Override
    public void onBindViewHolder(FeedbackViewHolder holder, int position) {
        MessFeedback feedback = feedbackList.get(position);
        holder.feedbackTextView.setText(feedback.getFeedback());
        holder.timestampTextView.setText(feedback.getTimestamp());
    }

    @Override
    public int getItemCount() {
        return feedbackList.size();
    }

    public static class FeedbackViewHolder extends RecyclerView.ViewHolder {
        TextView feedbackTextView, timestampTextView;

        public FeedbackViewHolder(View itemView) {
            super(itemView);
            feedbackTextView = itemView.findViewById(R.id.tv_feedback);
            timestampTextView = itemView.findViewById(R.id.tv_timestamp);
        }
    }
}
