package com.example.roombasedattendance;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
        import android.os.Bundle;
        import android.view.View;
        import android.widget.Button;
        import android.widget.TextView;
        import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TextView tvTitle;
    private Button btnStudentLogin;
    private Button btnAuthorityLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // Ensure your XML file is named activity_main.xml

        // Initialize UI components
        tvTitle = findViewById(R.id.tv_title);
        btnStudentLogin = findViewById(R.id.btn_student_login);
        btnAuthorityLogin = findViewById(R.id.btn_authority_login);

        // Set click listener for Student Login button
        btnStudentLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Handle Student Login action
                Intent studentIntent = new Intent(MainActivity.this,StudentloginActivity.class);
                startActivity(studentIntent);
            }
        });

        // Set click listener for Hostel Authority Login button
        btnAuthorityLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Handle Authority Login action
                Intent authorityIntent = new Intent(MainActivity.this, AuthorityloginActivity.class);
                startActivity(authorityIntent);
            }
        });
    }
}
