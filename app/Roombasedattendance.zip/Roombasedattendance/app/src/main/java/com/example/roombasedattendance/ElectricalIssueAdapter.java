package com.example.roombasedattendance;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.example.roombasedattendance.R;
import java.util.List;

public class ElectricalIssueAdapter extends RecyclerView.Adapter<ElectricalIssueAdapter.IssueViewHolder> {

    private List<ElectricalIssue> issueList;

    public ElectricalIssueAdapter(List<ElectricalIssue> issueList) {
        this.issueList = issueList;
    }

    @Override
    public IssueViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_electrical_issue, parent, false);
        return new IssueViewHolder(view);
    }

    @Override
    public void onBindViewHolder(IssueViewHolder holder, int position) {
        ElectricalIssue issue = issueList.get(position);
        holder.issueDescriptionTextView.setText(issue.getIssueDescription());
        holder.roomNumberTextView.setText("Room: " + issue.getRoomNumber());
        holder.registrationNumberTextView.setText("Reg No: " + issue.getRegistrationNumber());
        holder.studentNameTextView.setText("Student: " + issue.getStudentName());
        holder.timestampTextView.setText("Reported on: " + issue.getTimestamp());
    }

    @Override
    public int getItemCount() {
        return issueList.size();
    }

    public static class IssueViewHolder extends RecyclerView.ViewHolder {
        TextView issueDescriptionTextView, roomNumberTextView, registrationNumberTextView, studentNameTextView, timestampTextView;

        public IssueViewHolder(View itemView) {
            super(itemView);
            issueDescriptionTextView = itemView.findViewById(R.id.tv_issue_description);
            roomNumberTextView = itemView.findViewById(R.id.tv_room_number);
            registrationNumberTextView = itemView.findViewById(R.id.tv_registration_number);
            studentNameTextView = itemView.findViewById(R.id.tv_student_name);
            timestampTextView = itemView.findViewById(R.id.tv_timestamp);
        }
    }
}
