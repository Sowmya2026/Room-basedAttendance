package com.example.roombasedattendance;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.io.ByteArrayOutputStream;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

public class StdattendanceActivity extends AppCompatActivity {

    private static final int CAMERA_REQUEST_CODE = 101;

    private TextInputEditText attendanceRoomNumber;
    private Button captureAttendanceButton;
    private FirebaseFirestore firestore;

    // Register ActivityResultLauncher for camera
    private ActivityResultLauncher<Intent> cameraLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getResultCode() == RESULT_OK) {
                    Bitmap capturedImage = (Bitmap) result.getData().getExtras().get("data");
                    checkAttendance(capturedImage);
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stdattendance);

        // Initialize UI elements
        attendanceRoomNumber = findViewById(R.id.attendanceRoomNumber);
        captureAttendanceButton = findViewById(R.id.captureAttendanceButton);

        // Initialize Firestore
        firestore = FirebaseFirestore.getInstance();

        // Set up capture button with time check
        captureAttendanceButton.setOnClickListener(v -> checkTimeAndCapture());

        // Handle camera permission
        checkCameraPermission();

        // Schedule marking absent after 9 PM
        scheduleAbsentMarking();
    }

    private void checkTimeAndCapture() {
        Calendar calendar = Calendar.getInstance();
        int currentHour = calendar.get(Calendar.HOUR_OF_DAY);

        // Check if current time is within 7 PM to 9 PM (19:00 to 21:00)
        if (currentHour >= 13 && currentHour <= 21) {
            captureAttendanceImage();
        } else {
            Toast.makeText(this, "Camera access is allowed only between 7 PM and 9 PM.", Toast.LENGTH_SHORT).show();
        }
    }

    private void captureAttendanceImage() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
            cameraLauncher.launch(cameraIntent);
        } else {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, CAMERA_REQUEST_CODE);
        }
    }

    private void checkAttendance(Bitmap capturedImage) {
        String roomNumber = attendanceRoomNumber.getText().toString().trim();

        if (roomNumber.isEmpty()) {
            Toast.makeText(this, "Please enter a room number", Toast.LENGTH_SHORT).show();
            return;
        }

        // Convert captured image to Base64 string for comparison
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        capturedImage.compress(Bitmap.CompressFormat.JPEG, 100, byteArrayOutputStream);
        byte[] byteArray = byteArrayOutputStream.toByteArray();
        String capturedBase64String = Base64.encodeToString(byteArray, Base64.DEFAULT);

        // Fetch registered students for the specified room
        firestore.collection("roomRegistrations")
                .document(roomNumber)
                .collection("students")
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful() && !task.getResult().isEmpty()) {
                        boolean isMatched = false;
                        for (DocumentSnapshot document : task.getResult()) {
                            String registeredImageString = document.getString("imageBase64");

                            if (compareFaces(registeredImageString, capturedBase64String)) {
                                isMatched = true;
                                String studentName = document.getString("name");
                                markAttendance(roomNumber, studentName, "present");
                                Toast.makeText(this, "Attendance marked for " + studentName, Toast.LENGTH_SHORT).show();
                                break;
                            }
                        }
                        if (!isMatched) {
                            Toast.makeText(this, "Face not recognized in this room", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(this, "No registered students for this room", Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(e -> Toast.makeText(this, "Error fetching data: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }

    private boolean compareFaces(String registeredImageString, String capturedImageString) {
        return registeredImageString.equals(capturedImageString);
    }

    private void markAttendance(String roomNumber, String studentName, String status) {
        // Store attendance in Firestore
        Map<String, String> attendanceData = new HashMap<>();
        attendanceData.put("status", status);

        firestore.collection("attendance")
                .document(roomNumber)
                .collection("students")
                .document(studentName)
                .set(attendanceData)
                .addOnSuccessListener(aVoid -> {
                    if (status.equals("present")) {
                        Toast.makeText(this, "Attendance recorded for " + studentName, Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Error marking attendance: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }

    private void scheduleAbsentMarking() {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, 21);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);

        long delay = calendar.getTimeInMillis() - System.currentTimeMillis();
        if (delay < 0) {
            delay += 24 * 60 * 60 * 1000;  // if time has passed, set to next day
        }

        new Timer().schedule(new TimerTask() {
            @Override
            public void run() {
                markAllAbsent();
            }
        }, delay);
    }

    private void markAllAbsent() {
        firestore.collection("roomRegistrations")
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        for (DocumentSnapshot roomDocument : task.getResult()) {
                            String roomNumber = roomDocument.getId();
                            firestore.collection("roomRegistrations")
                                    .document(roomNumber)
                                    .collection("students")
                                    .get()
                                    .addOnCompleteListener(studentTask -> {
                                        if (studentTask.isSuccessful()) {
                                            for (DocumentSnapshot studentDocument : studentTask.getResult()) {
                                                String studentName = studentDocument.getString("name");
                                                firestore.collection("attendance")
                                                        .document(roomNumber)
                                                        .collection("students")
                                                        .document(studentName)
                                                        .get()
                                                        .addOnCompleteListener(attendanceTask -> {
                                                            if (attendanceTask.isSuccessful() && !attendanceTask.getResult().exists()) {
                                                                // Mark absent if no attendance record found
                                                                markAttendance(roomNumber, studentName, "absent");
                                                            }
                                                        });
                                            }
                                        }
                                    });
                        }
                    }
                });
    }

    private void checkCameraPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, CAMERA_REQUEST_CODE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Camera permission granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Camera permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
