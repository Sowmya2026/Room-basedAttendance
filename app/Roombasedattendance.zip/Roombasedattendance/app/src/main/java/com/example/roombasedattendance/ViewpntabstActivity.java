package com.example.roombasedattendance;

import android.os.Bundle;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

public class ViewpntabstActivity extends AppCompatActivity {

    private TextView tvTotalRegisteredStudents, tvTotalPresentStudents, tvTotalAbsentStudents;
    private ListView lvAbsenteeStudents;
    private FirebaseFirestore firestore;
    private int totalRegisteredCount = 0;
    private int totalPresentCount = 0;
    private int totalAbsentCount = 0;

    private List<String> absentStudentList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_viewpntabst);

        // Initialize UI components
        tvTotalRegisteredStudents = findViewById(R.id.tv_total_registered_students);
        tvTotalPresentStudents = findViewById(R.id.tv_total_present_students);
        tvTotalAbsentStudents = findViewById(R.id.tv_total_absent_students);
        lvAbsenteeStudents = findViewById(R.id.lv_absentee_students);

        // Initialize Firestore and lists
        firestore = FirebaseFirestore.getInstance();
        absentStudentList = new ArrayList<>();

        // Fetch data from Firestore
        fetchRegisteredStudents();
        fetchAttendanceData();
    }

    private void fetchRegisteredStudents() {
        firestore.collection("roomRegistrations")
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        totalRegisteredCount = task.getResult().size();
                        tvTotalRegisteredStudents.setText("Total Registered Students: " + totalRegisteredCount);
                    } else {
                        Toast.makeText(this, "Error fetching registered students.", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void fetchAttendanceData() {
        firestore.collection("attendance")
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        totalPresentCount = 0;
                        totalAbsentCount = 0;
                        absentStudentList.clear();

                        for (DocumentSnapshot roomDocument : task.getResult()) {
                            String roomNumber = roomDocument.getId();

                            roomDocument.getReference()
                                    .collection("students")
                                    .get()
                                    .addOnCompleteListener(studentsTask -> {
                                        if (studentsTask.isSuccessful()) {
                                            for (DocumentSnapshot studentDoc : studentsTask.getResult()) {
                                                String studentName = studentDoc.getId();
                                                String attendanceStatus = studentDoc.getString("status");

                                                if ("present".equals(attendanceStatus)) {
                                                    totalPresentCount++;
                                                } else if ("absent".equals(attendanceStatus)) {
                                                    absentStudentList.add(studentName + " - Room: " + roomNumber);
                                                    totalAbsentCount++;
                                                }
                                            }

                                            // Update the UI for attendance counts
                                            tvTotalPresentStudents.setText("Total Present Students: " + totalPresentCount);
                                            tvTotalAbsentStudents.setText("Total Absent Students: " + totalAbsentCount);

                                            // Update the absentee list view
                                            updateAbsenteeListView();
                                        }
                                    });
                        }
                    } else {
                        Toast.makeText(this, "Error fetching attendance data.", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void updateAbsenteeListView() {
        // Display absentee students
        StudentListAdapter absenteeAdapter = new StudentListAdapter(this, absentStudentList);
        lvAbsenteeStudents.setAdapter(absenteeAdapter);
    }
}
