package com.example.roombasedattendance;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class StdelectricalissuesActivity extends AppCompatActivity {

    private EditText etIssueDescription, etRoomNumber, etRegistrationNumber, etStudentName;
    private Button btnSubmitIssue;
    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stdelectricalissues);

        etIssueDescription = findViewById(R.id.et_electrical_issue);
        etRoomNumber = findViewById(R.id.et_electrical_room_number);
        etRegistrationNumber = findViewById(R.id.et_electrical_reg_number);
        etStudentName = findViewById(R.id.et_electrical_student_name);
        btnSubmitIssue = findViewById(R.id.btn_submit_electrical_issue);

        // Initialize Firebase Database reference under "authorityLogin/electrical_issues"
        databaseReference = FirebaseDatabase.getInstance().getReference("authorityLogin").child("electrical_issues");

        btnSubmitIssue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String issueDescription = etIssueDescription.getText().toString().trim();
                String roomNumber = etRoomNumber.getText().toString().trim();
                String registrationNumber = etRegistrationNumber.getText().toString().trim();
                String studentName = etStudentName.getText().toString().trim();

                if (TextUtils.isEmpty(issueDescription) || TextUtils.isEmpty(roomNumber) || TextUtils.isEmpty(registrationNumber) || TextUtils.isEmpty(studentName)) {
                    Toast.makeText(StdelectricalissuesActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                } else {
                    String timestamp = String.valueOf(System.currentTimeMillis());

                    // Create a new ElectricalIssue object
                    ElectricalIssue issue = new ElectricalIssue(issueDescription, roomNumber, registrationNumber, studentName, timestamp);

                    // Push the issue to Firebase
                    databaseReference.push().setValue(issue);

                    Toast.makeText(StdelectricalissuesActivity.this, "Issue submitted successfully", Toast.LENGTH_SHORT).show();
                    etIssueDescription.setText("");  // Clear input fields
                    etRoomNumber.setText("");
                    etRegistrationNumber.setText("");
                    etStudentName.setText("");
                }
            }
        });
    }
}
