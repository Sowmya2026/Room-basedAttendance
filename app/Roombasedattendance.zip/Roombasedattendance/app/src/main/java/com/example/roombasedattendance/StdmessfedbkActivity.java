package com.example.roombasedattendance;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class StdmessfedbkActivity extends AppCompatActivity {

    private EditText etMessFeedback;
    private Button btnSubmitFeedback;
    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stdmessfedbk);

        etMessFeedback = findViewById(R.id.et_mess_feedback);
        btnSubmitFeedback = findViewById(R.id.btn_submit_feedback);

        // Initialize Firebase Database reference to the new path "authorityLogin/mess_feedback"
        databaseReference = FirebaseDatabase.getInstance().getReference("authorityLogin").child("mess_feedback");

        btnSubmitFeedback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String feedback = etMessFeedback.getText().toString().trim();

                if (TextUtils.isEmpty(feedback)) {
                    Toast.makeText(StdmessfedbkActivity.this, "Please enter your feedback", Toast.LENGTH_SHORT).show();
                } else {
                    String timestamp = String.valueOf(System.currentTimeMillis());

                    // Create a new MessFeedback object
                    MessFeedback messFeedback = new MessFeedback(feedback, timestamp);

                    // Push the feedback to Firebase
                    databaseReference.push().setValue(messFeedback);

                    Toast.makeText(StdmessfedbkActivity.this, "Feedback submitted successfully", Toast.LENGTH_SHORT).show();
                    etMessFeedback.setText("");  // Clear the feedback input field
                }
            }
        });
    }
}
