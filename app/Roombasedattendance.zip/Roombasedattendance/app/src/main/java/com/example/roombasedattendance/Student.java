package com.example.roombasedattendance;

public class Student {

    private String name;      // Student's name
    private String faceData;  // Student's face data (Base64 string)

    // Constructor to initialize both name and faceData
    public Student(String name, String faceData) {
        this.name = name;
        this.faceData = faceData;
    }

    // Getter and Setter for 'name'
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    // Getter and Setter for 'faceData'
    public String getFaceData() {
        return faceData;
    }

    public void setFaceData(String faceData) {
        this.faceData = faceData;
    }
}
