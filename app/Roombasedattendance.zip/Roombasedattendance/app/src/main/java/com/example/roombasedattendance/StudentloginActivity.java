package com.example.roombasedattendance;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class StudentloginActivity extends AppCompatActivity {

    EditText etStudentId, etStudentPassword;
    Button loginButton;
    ProgressBar progressBar;
    FirebaseAuth mAuth;
    TextView tvSignUpLink;
    DatabaseReference mDatabase; // Reference to Firebase Realtime Database

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_studentlogin);

        // Initialize Firebase Auth and Database
        mAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference(); // Get reference to database

        // Initialize UI components
        etStudentId = findViewById(R.id.et_student_id);
        etStudentPassword = findViewById(R.id.et_student_password);
        loginButton = findViewById(R.id.loginstudent);
        progressBar = findViewById(R.id.progressBar);  // Reference the ProgressBar from XML
        tvSignUpLink = findViewById(R.id.tv_student_singup_link);

        // Set click listener for the Login button
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Show progress bar
                progressBar.setVisibility(View.VISIBLE);

                // Retrieve entered student details
                final String studentId = etStudentId.getText().toString().trim();
                final String password = etStudentPassword.getText().toString().trim();

                // Validate inputs
                if (TextUtils.isEmpty(studentId)) {
                    Toast.makeText(StudentloginActivity.this, "Enter Student ID", Toast.LENGTH_SHORT).show();
                    progressBar.setVisibility(View.GONE);
                    return;
                }
                if (TextUtils.isEmpty(password)) {
                    Toast.makeText(StudentloginActivity.this, "Enter Password", Toast.LENGTH_SHORT).show();
                    progressBar.setVisibility(View.GONE);
                    return;
                }

                // Make sure the studentId is a valid format (for example, alphanumeric)
                if (!studentId.matches("[a-zA-Z0-9]+")) {
                    Toast.makeText(StudentloginActivity.this, "Invalid Student ID", Toast.LENGTH_SHORT).show();
                    progressBar.setVisibility(View.GONE);
                    return;
                }

                // Use the studentId as the email for Firebase authentication
                String email = studentId + "@vitstudent.ac.in";

                // Sign in with Firebase Auth
                mAuth.signInWithEmailAndPassword(email, password)
                        .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                // Hide progress bar
                                progressBar.setVisibility(View.GONE);

                                if (task.isSuccessful()) {
                                    FirebaseUser user = mAuth.getCurrentUser();
                                    Toast.makeText(StudentloginActivity.this, "Login successful", Toast.LENGTH_SHORT).show();

                                    // Retrieve student data from Firebase Realtime Database using studentId
                                    if (user != null) {
                                        // Use studentId directly to reference the database
                                        mDatabase.child("studentlogin").child(studentId).addListenerForSingleValueEvent(new ValueEventListener() {
                                            @Override
                                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                                if (dataSnapshot.exists()) {
                                                    // Assuming you have data like 'name' and 'regNumber' in your database
                                                    String name = dataSnapshot.child("name").getValue(String.class);
                                                    String regNumber = dataSnapshot.child("regNumber").getValue(String.class);

                                                    // Now you have the student data, and you can use it in the app
                                                    Toast.makeText(StudentloginActivity.this, "Welcome " + name, Toast.LENGTH_SHORT).show();

                                                    // Navigate to StudentHomeActivity with the student data (if needed)
                                                    Intent intent = new Intent(StudentloginActivity.this, StudenthomeActivity.class);
                                                    intent.putExtra("userName", name);
                                                    intent.putExtra("userRegNumber", regNumber);
                                                    startActivity(intent);
                                                    finish();
                                                } else {
                                                    Toast.makeText(StudentloginActivity.this, "No data found for the student", Toast.LENGTH_SHORT).show();
                                                }
                                            }

                                            @Override
                                            public void onCancelled(@NonNull DatabaseError databaseError) {
                                                // Handle database read failure
                                                Toast.makeText(StudentloginActivity.this, "Error fetching student data", Toast.LENGTH_SHORT).show();
                                            }
                                        });
                                    }
                                } else {
                                    // Authentication failed
                                    String errorMessage = task.getException().getMessage();
                                    Toast.makeText(StudentloginActivity.this, "Authentication failed: " + errorMessage, Toast.LENGTH_SHORT).show();
                                    // Log the error for debugging
                                    Log.e("AuthError", "Login failed: " + errorMessage);
                                }
                            }
                        });
            }
        });

        // Set click listener for the Sign Up link
        tvSignUpLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to Signup Activity
                Intent intent = new Intent(StudentloginActivity.this, StudentsignupActivity.class);
                startActivity(intent);
            }
        });
    }
}
