package com.example.roombasedattendance;

public class ElectricalIssue {
    private String issueDescription;
    private String roomNumber;
    private String registrationNumber;
    private String studentName;
    private String timestamp;

    // Default constructor required for calls to DataSnapshot.getValue(ElectricalIssue.class)
    public ElectricalIssue() {
    }

    // Constructor for the issue object
    public ElectricalIssue(String issueDescription, String roomNumber, String registrationNumber, String studentName, String timestamp) {
        this.issueDescription = issueDescription;
        this.roomNumber = roomNumber;
        this.registrationNumber = registrationNumber;
        this.studentName = studentName;
        this.timestamp = timestamp;
    }

    public String getIssueDescription() {
        return issueDescription;
    }

    public void setIssueDescription(String issueDescription) {
        this.issueDescription = issueDescription;
    }

    public String getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }

    public String getRegistrationNumber() {
        return registrationNumber;
    }

    public void setRegistrationNumber(String registrationNumber) {
        this.registrationNumber = registrationNumber;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }
}
