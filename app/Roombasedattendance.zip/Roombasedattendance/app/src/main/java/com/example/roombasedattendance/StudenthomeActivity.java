package com.example.roombasedattendance;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;

public class StudenthomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_studenthome); // Ensure XML layout file is named activity_studenthome.xml
    }

    // Open Student Attendance Activity
    public void openStudentAttendance(View view) {
        Intent intent = new Intent(StudenthomeActivity.this, StdattendanceActivity.class);
        startActivity(intent);
    }

    // Open Hostel Events Activity
    public void openHostelEvents(View view) {
        Intent intent = new Intent(StudenthomeActivity.this, StdeventActivity.class);
        startActivity(intent);
    }

    // Open Mess Feedback Activity
    public void openMessFeedback(View view) {
        Intent intent = new Intent(StudenthomeActivity.this, StdmessfedbkActivity.class);
        startActivity(intent);
    }

    // Open Electrical Issues Reporting Activity
    public void openElectricalIssues(View view) {
        Intent intent = new Intent(StudenthomeActivity.this,StdelectricalissuesActivity.class);
        startActivity(intent);
    }

    // Open Health Issues Reporting Activity
    public void openHealthIssues(View view) {
        Intent intent = new Intent(StudenthomeActivity.this, StdhealthissuesActivity.class);
        startActivity(intent);
    }
}
