package com.example.roombasedattendance;

public class HealthIssue {

    private String healthIssue;
    private String roomNumber;
    private String regNumber;
    private String studentName;

    // Default constructor for Firebase
    public HealthIssue() {
    }

    // Constructor with parameters
    public HealthIssue(String healthIssue, String roomNumber, String regNumber, String studentName) {
        this.healthIssue = healthIssue;
        this.roomNumber = roomNumber;
        this.regNumber = regNumber;
        this.studentName = studentName;
    }

    // Getters and setters for the fields
    public String getHealthIssue() {
        return healthIssue;
    }

    public void setHealthIssue(String healthIssue) {
        this.healthIssue = healthIssue;
    }

    public String getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }

    public String getRegNumber() {
        return regNumber;
    }

    public void setRegNumber(String regNumber) {
        this.regNumber = regNumber;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }
}
