package com.example.roombasedattendance;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class StdhealthissuesActivity extends AppCompatActivity {

    private EditText etHealthIssue, etRoomNumber, etRegNumber, etStudentName;
    private DatabaseReference database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stdhealthissues);

        // Initialize Firebase database reference under "authorityLogin/health_issues"
        database = FirebaseDatabase.getInstance().getReference("authorityLogin").child("health_issues");

        // Initialize Views
        etHealthIssue = findViewById(R.id.et_health_issue);
        etRoomNumber = findViewById(R.id.et_health_room_number);
        etRegNumber = findViewById(R.id.et_health_reg_number);
        etStudentName = findViewById(R.id.et_health_student_name);
    }

    // Method to handle health issue submission
    public void submitHealthIssue(View view) {
        String healthIssue = etHealthIssue.getText().toString();
        String roomNumber = etRoomNumber.getText().toString();
        String regNumber = etRegNumber.getText().toString();
        String studentName = etStudentName.getText().toString();

        if (healthIssue.isEmpty() || roomNumber.isEmpty() || regNumber.isEmpty() || studentName.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields.", Toast.LENGTH_SHORT).show();
            return;
        }

        String id = database.push().getKey();
        HealthIssue newIssue = new HealthIssue(healthIssue, roomNumber, regNumber, studentName);

        if (id != null) {
            database.child(id).setValue(newIssue);
            Toast.makeText(this, "Health Issue Submitted.", Toast.LENGTH_SHORT).show();
            finish();
        }
    }
}
