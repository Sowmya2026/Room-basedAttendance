package com.example.roombasedattendance;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AuthorityloginActivity extends AppCompatActivity {

    // Predefined login credentials
    private static final String AUTHORITY_ID = "50321";
    private static final String AUTHORITY_PASSWORD = "authority123";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_authoritylogin); // Ensure this layout file exists

        // Set up button click listeners here if required, or in XML
    }

    // Method for handling authority login
    public void hostelAuthorityLogin(View view) {
        EditText authorityId = findViewById(R.id.et_authority_id);
        EditText password = findViewById(R.id.et_authority_password);

        String authorityID = authorityId.getText().toString().trim();
        String pass = password.getText().toString().trim();

        // Validate credentials
        if (AUTHORITY_ID.equals(authorityID) && AUTHORITY_PASSWORD.equals(pass)) {
            // Successful login
            Toast.makeText(this, "Login Successful", Toast.LENGTH_SHORT).show();

            // Navigate to the Authority Home Activity
            Intent intent = new Intent(this, AuthorityhomeActivity.class); // Ensure AuthorityhomeActivity exists
            startActivity(intent);
        } else if (authorityID.isEmpty() || pass.isEmpty()) {
            // Missing input
            Toast.makeText(this, "Please enter both Authority ID and Password", Toast.LENGTH_SHORT).show();
        } else {
            // Invalid credentials
            Toast.makeText(this, "Invalid Authority ID or Password", Toast.LENGTH_SHORT).show();
        }
    }

    // Method to navigate back to the main home page
    public void goToHomePage(View view) {
        Intent intent = new Intent(this, AuthorityhomeActivity.class); // Replace MainActivity with your actual home activity
        startActivity(intent);
    }
}
