package com.example.roombasedattendance;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class AuthorityhomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_authorityhome); // Ensure the XML layout filename is correct
    }

    // Method to open the Student Face Registration screen
    public void registerStudentFace(View view) {
        // TODO: Implement the Student Face Registration activity
        Intent intent = new Intent(AuthorityhomeActivity.this, FaceregistrationActivity.class);
        startActivity(intent);
    }

    // Method to open the View Attendance screen
    public void viewAttendance(View view) {
        // TODO: Implement the View Attendance activity
        Intent intent = new Intent(AuthorityhomeActivity.this, ViewpntabstActivity.class);
        startActivity(intent);
    }

    // Method to open the Schedule Hostel Events screen
    public void viewHostelEvents(View view) {
        // TODO: Implement the Hostel Event Scheduling activity
        Intent intent = new Intent(AuthorityhomeActivity.this, SheduleeventActivity.class);
        startActivity(intent);
    }

    // Method to open the View Mess Feedback screen
    public void viewMessFeedback(View view) {
        // TODO: Implement the Mess Feedback activity
        Intent intent = new Intent(AuthorityhomeActivity.this, ViewmessfdbkActivity.class);
        startActivity(intent);
    }

    // Method to open the View Electrical Issues screen
    public void viewElectricalIssues(View view) {
        // TODO: Implement the Electrical Issues activity
        Intent intent = new Intent(AuthorityhomeActivity.this, ViewelectricalissuesActivity.class);
        startActivity(intent);
    }

    // Method to open the View Health Issues screen
    public void viewHealthIssues(View view) {
        // TODO: Implement the Health Issues activity
        Intent intent = new Intent(AuthorityhomeActivity.this, ViewhealthissuesActivity.class);
        startActivity(intent);
    }
}

